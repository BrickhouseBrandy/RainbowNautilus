# Research

This folder contains research materials, academic papers, case studies, and technical reports that support and inform the Rainbow Nautilus project.

## Structure

### papers/
Academic papers, research articles, and scientific studies related to:
- Floating architecture
- Water purification systems
- Sustainable materials
- Climate adaptation
- Marine ecology
- Renewable energy systems

### case-studies/
Documentation of existing projects and implementations:
- LIFT House (Bangladesh amphibious housing)
- MAST "Land on Water" system
- Biomatrix floating wetlands
- Science Barge
- Living Machine installations
- Other relevant floating/adaptive architecture projects

### materials-research/
Specific research on materials and technologies:
- **geopolymers/** - Ancient and modern geopolymer research, concrete alternatives
- **sustainable-foams/** - Mycelium foam, algae-based foam, non-petroleum buoyancy materials
- **mycology/** - Fungal water treatment, polyphosphate accumulation, bioremediation

## Citation Standards

When adding research materials:
- Include full bibliographic information
- Add a brief summary/abstract
- Note key findings relevant to Rainbow Nautilus
- Respect copyright - link to sources when full text cannot be shared
- Create .md summary files for papers with key takeaways

## Research Needs

Areas where more research is needed:
- Long-term performance of geopolymers in saltwater
- Mycological filtration in brackish water environments
- Optimal oyster cultivation methods for various climates
- Cost-benefit analysis of different sustainable foam materials
- Community acceptance and social impact studies
- Regulatory frameworks for floating developments

## Contributing Research

When submitting research materials:
1. Ensure you have rights to share the material
2. Provide proper attribution
3. Create a summary document highlighting relevance to Rainbow Nautilus
4. Tag with relevant keywords (e.g., #water-filtration, #sustainable-materials)
5. Update this README with new categories as needed

## Open Research Questions

- What is the optimal balance between oyster density and water purification efficiency?
- How can Living Machine systems be adapted for floating environments?
- What are the most cost-effective sustainable materials for different climatic zones?
- How do different H-block connection methods perform under stress?
- What is the environmental impact assessment over 20+ years?

Contributions answering these questions are especially welcome!
