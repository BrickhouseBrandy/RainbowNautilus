# Designs

This folder contains all design files, blueprints, CAD models, and technical drawings for Rainbow Nautilus components.

## Structure

### h-blocks/
Design files for the modular H-block building system:
- **standard-blocks/** - Common block designs (various sizes, standard connections)
- **specialized-blocks/** - Purpose-specific blocks (utility channels, wetland integration, etc.)
- **connection-systems/** - Mortise-tenon connections, pin systems, sealant specifications

### floating-platforms/
Platform designs including foundation systems, buoyancy calculations, and anchoring specifications.

### housing-modules/
Residential unit designs that integrate with the H-block platform system.

### public-spaces/
Community areas, gathering spaces, walkways, and shared facilities.

## File Formats

We encourage designs in open formats when possible:
- CAD: .dxf, .dwg, .step
- 3D Models: .stl, .obj, .blend (Blender)
- Diagrams: .svg, .pdf
- Documentation: .md with embedded images

## Design Principles

All designs should consider:
1. Modularity and adaptability
2. Use of sustainable materials
3. Ease of assembly and disassembly
4. Resilience to water level changes and weather
5. Integration with other Rainbow Nautilus systems
6. Accessibility for maintenance

## Contributing Designs

When submitting designs:
- Include both source files and rendered views
- Provide material specifications
- Document dimensions and tolerances
- Include assembly notes
- Reference any standards or building codes considered
