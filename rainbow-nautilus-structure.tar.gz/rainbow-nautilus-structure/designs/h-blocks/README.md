# H-Block Design System

The H-block system is inspired by the ancient interlocking stone blocks of Pumapunku, adapted for modern sustainable floating architecture.

## Design Philosophy

The H-block system provides:
- **Modularity**: Easy assembly, disassembly, and reconfiguration
- **Standardization**: Compatible across sizes while maintaining flexibility
- **Integration**: Built-in channels for utilities and systems
- **Sustainability**: Multiple material options for different needs
- **Adaptability**: Scalable from small structures to large communities

## Block Structure

### standard-blocks/
Common block designs in various sizes:
- Small blocks: Personal/detail scale
- Medium blocks: Standard building units
- Large blocks: Structural/foundational scale
- Dimensions follow modular ratio system for compatibility

### specialized-blocks/
Purpose-specific designs:
- **Utility blocks**: Integrated channels for wiring, plumbing
- **Corner blocks**: Specialized geometry for turning points
- **Connection blocks**: Adapters between different block sizes
- **Wetland blocks**: Designed to support floating plants
- **Transparent blocks**: Allow light penetration for underlying systems
- **Foundation blocks**: Enhanced buoyancy for platform bases

### connection-systems/
Methods for joining blocks:
- **Mortise-and-tenon joints**: Primary interlocking method
- **Pin systems**: Stainless steel pins with marine-grade coating
- **Sealants**: Waterproof, chemical-resistant materials
- **Flexible connectors**: Allow movement while maintaining integrity

## Material Options

Blocks can be manufactured from various materials depending on application:

### 1. Sustainable Foams (for buoyancy)
- **Mycelium foam**: Grown from fungal roots and agricultural waste
- **Algae-based foam**: Carbon-negative, biodegradable
- **Cork-based foam**: Natural, renewable, water-resistant
- **Recycled glass foam**: Made from recycled bottles

### 2. Geopolymers (for structure)
- Ancient-inspired geopolymer sandstone
- Modern geopolymer concrete formulations
- CNF-reinforced geopolymer foam (lightweight + strong)
- Regional variations using local materials

### 3. Recycled Materials
- **Ocean plastic**: Processing marine debris into blocks
- **Post-consumer recycled plastic**: Various plastic types
- **Recycled aggregate**: In geopolymer mixes

### 4. Hempcrete (for specific applications)
- Non-load-bearing walls
- Insulation components
- May be mixed with geopolymer for enhanced properties

## Design Specifications

### Dimensions
- All blocks based on modular grid system
- Standard unit: [to be determined through testing]
- Scaling factor: [typically 2x, 3x, 4x the base unit]
- Tolerance specifications: [±x mm]

### Structural Requirements
- Compressive strength: [varies by material and application]
- Buoyancy capacity: [varies by block size and material]
- Connection strength: [minimum load requirements]
- Water absorption: [maximum percentage]
- Durability: [expected lifespan in marine environment]

### Utility Channels
- Standard conduit sizes for electrical, plumbing
- Minimum bend radius specifications
- Access point requirements
- Waterproofing standards
- Cable management specifications

## Manufacturing

### On-site Production
- Mold systems for various block types
- Material mixing and curing procedures
- Quality control standards
- Production timelines

### Distributed Manufacturing
- Local material sourcing guidelines
- Regional adaptations to available materials
- Collaboration with local manufacturers
- Quality certification process

## Testing Requirements

Before approving block designs:
1. **Structural testing**: Load bearing, compression, tension
2. **Environmental testing**: Saltwater immersion, UV exposure, freeze-thaw
3. **Connection testing**: Joint strength, repeated assembly/disassembly
4. **Buoyancy testing**: Long-term flotation, water absorption
5. **Material degradation**: Long-term performance in marine environment

## Current Development Status

- [ ] Finalize base unit dimensions
- [ ] Prototype standard block designs
- [ ] Test various material formulations
- [ ] Develop connection system specifications
- [ ] Create manufacturing guidelines
- [ ] Conduct structural testing
- [ ] Establish quality standards

## Contributing

We especially need:
- Structural engineers to validate designs
- Materials scientists to optimize formulations
- Manufacturing experts for production methods
- Prototyping and testing of physical blocks
- Cost analysis for different material options
- Regional adaptations for various climates

All contributions should include:
- CAD files or technical drawings
- Material specifications
- Structural calculations
- Manufacturing process notes
- Testing results (if available)
