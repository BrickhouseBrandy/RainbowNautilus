# Documentation

This folder contains all project documentation for Rainbow Nautilus.

## Structure

### overview/
High-level project vision, philosophy, and design principles. Start here to understand the "why" behind Rainbow Nautilus.

### technical-specs/
Detailed technical specifications for all major components including H-blocks, adaptive architecture systems, materials, and structural engineering details.

### implementation-guides/
Practical guides for implementing Rainbow Nautilus including site selection criteria, assembly instructions, maintenance procedures, and troubleshooting.

## Contributing to Documentation

When adding new documentation:
- Use clear, descriptive filenames
- Include a table of contents for longer documents
- Add diagrams and images where helpful (store in `/docs/images/`)
- Reference sources and research materials
- Keep language accessible while maintaining technical accuracy

## Documentation Standards

- Use Markdown (.md) format
- Include metadata (author, date, version) at the top of each document
- Cross-reference related documents
- Update the main README.md when adding significant new documentation
