# Rainbow Nautilus Repository Structure

This document provides an overview of how the Rainbow Nautilus repository is organized and how to navigate it.

## Quick Navigation

- **New to the project?** Start with the main [README.md](../README.md)
- **Want to contribute?** See [CONTRIBUTING.md](../CONTRIBUTING.md)
- **Looking for technical details?** Browse [/docs/technical-specs/](../docs/technical-specs/)
- **Want to see what's been built?** Check [/prototypes/](../prototypes/)
- **Looking for research?** Explore [/research/](../research/)
- **Ready to design?** Visit [/designs/](../designs/)

## Repository Structure

```
RainbowNautilus/
│
├── README.md                    # Project overview and introduction
├── LICENSE                      # GNU General Public License v3.0
├── CONTRIBUTING.md              # How to contribute to the project
├── CODE_OF_CONDUCT.md          # Community guidelines
├── ROADMAP.md                   # Development timeline and milestones
│
├── docs/                        # All project documentation
│   ├── overview/                # Project vision and philosophy
│   ├── technical-specs/         # Detailed technical specifications
│   └── implementation-guides/   # Practical implementation guides
│
├── designs/                     # Design files and blueprints
│   ├── h-blocks/               # Modular building block system
│   ├── floating-platforms/     # Foundation and platform designs
│   ├── housing-modules/        # Residential units
│   └── public-spaces/          # Community areas and facilities
│
├── systems/                     # Integrated systems documentation
│   ├── water-management/       # Water purification systems
│   │   ├── living-machine/
│   │   ├── mycological-filtration/
│   │   ├── oyster-cultivation/
│   │   └── biomatrix-wetlands/
│   ├── energy/                 # Renewable energy systems
│   ├── waste-management/       # Circular economy systems
│   └── smart-infrastructure/   # Monitoring and control
│
├── research/                    # Research materials and studies
│   ├── papers/                 # Academic papers and articles
│   ├── case-studies/           # Existing project documentation
│   └── materials-research/     # Specific material research
│       ├── geopolymers/
│       ├── sustainable-foams/
│       └── mycology/
│
├── community/                   # Community engagement
│   ├── discussion-topics/      # Ongoing conversations
│   ├── contributor-profiles/   # Active contributors
│   └── events/                 # Workshops, meetups, conferences
│
└── prototypes/                  # Actual builds and testing
    ├── small-scale-tests/      # Component testing
    └── pilot-projects/         # Full implementations
```

## Information Architecture

### By User Type

**Researchers and Academics:**
- Start with `/research/` for existing studies
- Contribute findings to appropriate research categories
- Check `/prototypes/` for real-world performance data

**Designers and Engineers:**
- Explore `/designs/` for technical drawings
- Review `/docs/technical-specs/` for requirements
- Contribute designs and improvements
- Test designs in `/prototypes/small-scale-tests/`

**Builders and Implementers:**
- Follow `/docs/implementation-guides/`
- Reference `/designs/` for construction plans
- Use `/systems/` for system integration
- Document your build in `/prototypes/`

**Community Organizers:**
- Engage through `/community/`
- Share local adaptations
- Organize events and workshops
- Build partnerships

**Potential Residents/Users:**
- Read `/docs/overview/` to understand the vision
- Review `/prototypes/pilot-projects/` for real examples
- Share feedback in `/community/discussion-topics/`
- Connect with implementers in your region

### By Component

**H-Block System:**
- Designs: `/designs/h-blocks/`
- Materials research: `/research/materials-research/`
- Prototypes: `/prototypes/small-scale-tests/`

**Water Purification:**
- System specs: `/systems/water-management/`
- Research: `/research/papers/`, `/research/mycology/`
- Case studies: `/research/case-studies/`
- Prototypes: `/prototypes/`

**Energy Systems:**
- Specifications: `/systems/energy/`
- Integration: `/systems/smart-infrastructure/`
- Design files: `/designs/`

**Complete Floating Community:**
- Vision: `/docs/overview/`
- Platform design: `/designs/floating-platforms/`
- Housing: `/designs/housing-modules/`
- All systems: `/systems/`
- Implementation: `/docs/implementation-guides/`
- Examples: `/prototypes/pilot-projects/`

## Version Control

- **Main branch**: Stable, tested designs and documentation
- **Development branches**: Work in progress, experimental designs
- **Release tags**: Major milestones and versions

## File Naming Conventions

- Use lowercase with hyphens: `h-block-standard-design.md`
- Include version numbers when relevant: `v1.0`, `v2.1`
- Date prototypes: `2025-03-slidell-prototype.md`
- Be descriptive: `oyster-cultivation-brackish-water-guide.md`

## Documentation Standards

All documentation should:
- Be written in Markdown (.md) format
- Include a clear title and description
- Have a table of contents for longer documents
- Reference sources and related documents
- Be kept up to date as designs evolve

## Contributing to the Structure

If you need to add a new category or reorganize:
1. Open an issue to discuss the change
2. Ensure it aligns with the overall organization
3. Update relevant README files
4. Update this structure document
5. Notify the community of significant changes

## Questions?

- Check existing documentation first
- Search issues for similar questions
- Ask in `/community/discussion-topics/`
- Reach out to core contributors

---

*This structure is designed to grow organically while maintaining organization. As the project evolves, this structure will be updated to serve the community's needs.*
